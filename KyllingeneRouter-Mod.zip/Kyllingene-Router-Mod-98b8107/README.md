# Router Mod
A [INDEV] fully-fledged mod for Mindustry. Upgrade of Kyllingene/ruoter-legacy

#### For Mindustry v6.0
Plan: at least one piece of content in every category

Implemented:
 - New Unit: Leg Router
 - New Turret: Bullet Router
 - New Ore: Router Ore
 - New Unit Factory: Unit Router
 - New Factory: Router Factory
 - New Melter: Router Smelter
 - New Seperator: Router Router
 - New Distribution: BIG Router
 - New Power Production: Router Burner
 - New Item: Router
 - New Liquid: Molten Router
 - New Processor: Command Router

Planned Features:
 - New Mender: Health Router
 - New Drill: Ore Router
