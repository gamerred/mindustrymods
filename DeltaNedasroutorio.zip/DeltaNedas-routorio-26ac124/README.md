# Routorio
Reality-shatterring router expansion mod for Mindustry.

Also check out [ReVision](https://github.com/Slava0135/reVision)

# Schematics
Schematics of every block can be created with `make -f schems.mk`.
On Linux-based operating systems you can then `make -f schems.mk install`.
Requires [pictoschem](https://bitbucket.org/DeltaNedas/pictoschem).

# License
All of routorio is licensed under the GNU GPLv3, available in [COPYING](/COPYING).
