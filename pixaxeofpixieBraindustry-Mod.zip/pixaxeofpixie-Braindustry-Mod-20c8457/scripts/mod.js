var mod = Vars.mods.locateMod("braindustry");
var x = mod.meta;
x.displayName = "[#af6ecc]Braindustry";
x.description = "[#f2ed5e]Huge mindustry mod, orienter to  end-game content.";
x.author = "[#af6ecc]PixaxeOfPixie";
