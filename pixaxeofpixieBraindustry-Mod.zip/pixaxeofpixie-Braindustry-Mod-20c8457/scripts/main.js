//require("mod");
require("graphenite");
require("exoticAlloy");
require("impulse");
require("synaps");
require("axon");
require("electron");
require("unitAbilities");
require("effects");

Vars.defaultServers.clear();
Vars.defaultServers.add(ServerGroup("Unjown Server", ["braindustryserver.ddns.net:25647"]));
//require("rotators");
