# Mindustry Mod by Pixaxeofpixie

[![Discord](https://img.shields.io/discord/704355237246402721.svg?color=7289da&label=discord&logo=discord&style=flat-square)](https://discord.gg/F7HA7zMPeD)
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fpixaxeofpixie%2FBraindustry-Mod&count_bg=%23859DFF&title_bg=%23B22AFF&icon=&icon_color=%2396EAFF&title=hits&edge_flat=false)](https://hits.seeyoufarm.com)
[![Stars](https://img.shields.io/github/stars/pixaxeofpixie/Braindustry-Mod?label=Star%20Me%21&style=social)](https://github.com/pixaxeofpixie/Braindustry-Mod/tree/master)
[![Steam](https://github.com/pixaxeofpixie/pictures/blob/main/steam32.png?raw=true)](https://steamcommunity.com/sharedfiles/filedetails/?id=2409840996)



Latest version - 1.4.2

## New content:
### -2 branches of units

### -More than 10 turrets

### -New redactor blocks

### -New liquids

### -New materials

# Mod Screenshots

![a](https://github.com/pixaxeofpixie/pictures/blob/main/screen2.png?raw=true)
![b](https://user-images.githubusercontent.com/63517945/102699428-a69ea400-4255-11eb-8bb0-484f630e79f3.png)
![c](https://user-images.githubusercontent.com/63517945/101539745-0f616300-39b0-11eb-99ec-5c2fc6d75d80.png)
