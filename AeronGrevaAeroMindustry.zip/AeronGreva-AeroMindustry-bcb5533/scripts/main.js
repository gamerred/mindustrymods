// require("energy-shield");

Events.on(ContentInitEvent, () => {
	print("[AeMin] AeroMindustry has been loaded!");
	});